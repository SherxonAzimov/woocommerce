<?php
/**
 * Title: Product Search
 * Slug: woocommerce/product-search-form
 * Inserter: no
 * Categories: WooCommerce
 */
?>
<!-- wp:search {"showLabel":false,"placeholder":"<?php echo esc_attr_x( 'Search products…', 'placeholder for search field', 'woocommerce' ); ?>","query":{"post_type":"product"}} /-->
